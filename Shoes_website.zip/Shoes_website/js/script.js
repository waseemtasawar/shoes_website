let menu = document.querySelector('#menu-bar');
let navbar = document.querySelector('.navbar');

menu.onclick =() =>{
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');
}


// Select the navigation bar

// Add an event listener for click to the menu bar
menu.addEventListener("click", function() {
    // Toggle the show class on click
    navbar.classList.toggle("show");
});

let slides = document.querySelectorAll('.slide-container');
let index = 0;

function next(){
    slides[index].classList.remove('active');
    index = (index + 1) % slides.length;
    slides[index].classList.add('active');
}

function prev(){
    slides[index].classList.remove('active');
    index = (index - 1 + slides.length) % slides.length;
    slides[index].classList.add('active');
}

document.querySelectorAll('.featured-image-1').forEach(image_1 =>{
    image_1.addEventListener('click', () =>{
        var src = image_1.getAttribute('src');
        document.querySelector('.big-image-1').src = src;
    });
});

document.querySelectorAll('.featured-image-2').forEach(image_2 =>{
    image_2.addEventListener('click', () =>{
        var src = image_2.getAttribute('src');
        document.querySelector('.big-image-2').src = src;
    });
});

document.querySelectorAll('.featured-image-3').forEach(image_3 =>{
    image_3.addEventListener('click', () =>{
        var src = image_3.getAttribute('src');
        document.querySelector('.big-image-3').src = src;
    });
});

window.onload = function() {
    loadHeaderFooter();
  }
  function loadHeaderFooter() {
    fetch('catalog.html')
      .then(response => response.text())
      .then(data => {
        document.getElementById('all_products').innerHTML = data;
      });
 
  }


// login validation

document.querySelector('form[action="#"]').addEventListener('submit', function(event) {
    event.preventDefault();
    
    var emailPhone = document.querySelector('input[type="text"]');
    var password = document.querySelector('input[type="password"]');

    if(emailPhone.value === '') {
        alert('Please enter your email or phone number.');
        return false;
    }
    
    if(password.value === '') {
        alert('Please enter your password.');
        return false;
    }

    alert('login  successful!');

    
});


// registration page

document.querySelector('form[action="#"]').addEventListener('submit', function(event) {
    event.preventDefault();
    
    var name = document.querySelector('input[placeholder="Enter your name"]');
    var username = document.querySelector('input[placeholder="Enter your username"]');
    var email = document.querySelector('input[placeholder="Enter your email"]');
    var number = document.querySelector('input[placeholder="Enter your number"]');
    var password = document.querySelector('input[placeholder="Enter your password"]');
    var confirm_password = document.querySelector('input[placeholder="Confirm your password"]');

    if(name.value === '') {
        alert('Please enter your name.');
        return false;
    }

    if(username.value === '') {
        alert('Please enter your username.');
        return false;
    }

    // simple check for email format
    var emailRegex = /\S+@\S+\.\S+/;
    if(!emailRegex.test(email.value)) {
        alert('Please enter a valid email.');
        return false;
    }

    if(number.value === '') {
        alert('Please enter your number.');
        return false;
    }

    if(password.value === '') {
        alert('Please enter your password.');
        return false;
    }

    if(confirm_password.value === '') {
        alert('Please confirm your password.');
        return false;
    }

    if(password.value !== confirm_password.value) {
        alert('Your passwords do not match.');
        return false;
    }

    alert('Registration successful!');
});

// add to cart

$('.like-btn').on('click', function() {
    $(this).toggleClass('is-active');
 });
 $('.minus-btn').on('click', function(e) {
    e.preventDefault();
    var $this = $(this);
    var $input = $this.closest('div').find('input');
    var value = parseInt($input.val());

    if (value > 1) {
        value = value - 1;
    } else {
        value = 0;
    }

    $input.val(value);

});

$('.plus-btn').on('click', function(e) {
    e.preventDefault();
    var $this = $(this);
    var $input = $this.closest('div').find('input');
    var value = parseInt($input.val());

    if (value < 100) {
        value = value + 1;
    } else {
        value = 100;
    }

    $input.val(value);
});





