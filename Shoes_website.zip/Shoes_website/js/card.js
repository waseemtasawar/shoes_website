document.getElementById('credit-card-form').addEventListener('submit', function(event) {
    // Prevent the form from submitting
    event.preventDefault();

    var cardNumber = document.getElementById('card-number').value;
    var cvv = document.getElementById('cvv').value;

    if (cardNumber.length != 16) {
        alert('Please enter a valid card number.');
        return false;
    }

    if (cvv.length < 3 || cvv.length > 4) {
        alert('Please enter a valid CVV.');
        return false;
    }

    alert('Payment successful!');
    // Redirect to the home page
    window.location.href = 'index.html'; // Replace 'home.html' with the path to your home page
});
